# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(readme-render src/readme-render.cpp)
set_property(TARGET readme-render PROPERTY CXX_STANDARD 11)
target_link_libraries(readme-render lionss pthread)

add_executable(strict-warnings src/strict-warnings.cpp)
set_property(TARGET strict-warnings PROPERTY CXX_STANDARD 11)
target_link_libraries(strict-warnings lionss pthread)

add_executable(build-shared src/build-shared.cpp)
set_property(TARGET build-shared PROPERTY CXX_STANDARD 11)
target_link_libraries(build-shared lionss pthread)

add_executable(signal-handling src/signal-handling.cpp)
set_property(TARGET signal-handling PROPERTY CXX_STANDARD 11)
target_link_libraries(signal-handling lionss pthread)

add_executable(android-arm64 src/android-arm64.cpp)
set_property(TARGET android-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-arm64 lionss pthread)

add_executable(bandwidth-bench src/bandwidth-bench.cpp)
set_property(TARGET bandwidth-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(bandwidth-bench lionss pthread)

add_executable(tutorial-build src/tutorial-build.cpp)
set_property(TARGET tutorial-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tutorial-build lionss pthread)

add_executable(autosar-check src/autosar-check.cpp)
set_property(TARGET autosar-check PROPERTY CXX_STANDARD 11)
target_link_libraries(autosar-check lionss pthread)

add_executable(nix-build src/nix-build.cpp)
set_property(TARGET nix-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nix-build lionss pthread)

add_executable(lsan src/lsan.cpp)
set_property(TARGET lsan PROPERTY CXX_STANDARD 11)
target_link_libraries(lsan lionss pthread)

add_executable(linux-riscv64 src/linux-riscv64.cpp)
set_property(TARGET linux-riscv64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-riscv64 lionss pthread)

add_executable(android-x86-64 src/android-x86-64.cpp)
set_property(TARGET android-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-x86-64 lionss pthread)

add_executable(verify-signatures src/verify-signatures.cpp)
set_property(TARGET verify-signatures PROPERTY CXX_STANDARD 11)
target_link_libraries(verify-signatures lionss pthread)

add_executable(guix-build src/guix-build.cpp)
set_property(TARGET guix-build PROPERTY CXX_STANDARD 11)
target_link_libraries(guix-build lionss pthread)

add_executable(header-guards src/header-guards.cpp)
set_property(TARGET header-guards PROPERTY CXX_STANDARD 11)
target_link_libraries(header-guards lionss pthread)

add_executable(strip-check src/strip-check.cpp)
set_property(TARGET strip-check PROPERTY CXX_STANDARD 11)
target_link_libraries(strip-check lionss pthread)

add_executable(dependency-graph src/dependency-graph.cpp)
set_property(TARGET dependency-graph PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-graph lionss pthread)

add_executable(msan src/msan.cpp)
set_property(TARGET msan PROPERTY CXX_STANDARD 11)
target_link_libraries(msan lionss pthread)

add_executable(permissions-audit src/permissions-audit.cpp)
set_property(TARGET permissions-audit PROPERTY CXX_STANDARD 11)
target_link_libraries(permissions-audit lionss pthread)

add_executable(sonarcloud src/sonarcloud.cpp)
set_property(TARGET sonarcloud PROPERTY CXX_STANDARD 11)
target_link_libraries(sonarcloud lionss pthread)

add_executable(mingw-build src/mingw-build.cpp)
set_property(TARGET mingw-build PROPERTY CXX_STANDARD 11)
target_link_libraries(mingw-build lionss pthread)

add_executable(aur-package src/aur-package.cpp)
set_property(TARGET aur-package PROPERTY CXX_STANDARD 11)
target_link_libraries(aur-package lionss pthread)

add_executable(modules-build src/modules-build.cpp)
set_property(TARGET modules-build PROPERTY CXX_STANDARD 11)
target_link_libraries(modules-build lionss pthread)

add_executable(msvc-build src/msvc-build.cpp)
set_property(TARGET msvc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(msvc-build lionss pthread)

add_executable(syft-sbom src/syft-sbom.cpp)
set_property(TARGET syft-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(syft-sbom lionss pthread)

add_executable(sanity-check src/sanity-check.cpp)
set_property(TARGET sanity-check PROPERTY CXX_STANDARD 11)
target_link_libraries(sanity-check lionss pthread)

add_executable(split-dwarf src/split-dwarf.cpp)
set_property(TARGET split-dwarf PROPERTY CXX_STANDARD 11)
target_link_libraries(split-dwarf lionss pthread)

add_executable(negative-tests src/negative-tests.cpp)
set_property(TARGET negative-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(negative-tests lionss pthread)

add_executable(release-dry-run src/release-dry-run.cpp)
set_property(TARGET release-dry-run PROPERTY CXX_STANDARD 11)
target_link_libraries(release-dry-run lionss pthread)

add_executable(advisory-sync src/advisory-sync.cpp)
set_property(TARGET advisory-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(advisory-sync lionss pthread)

