// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("lsan\n", stdout);
  return lionss_run_workload("lsan");
}
