// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("syft sbom\n", stdout);
  return lionss_run_workload("syft-sbom");
}
