// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("readme render\n", stdout);
  return lionss_run_workload("readme-render");
}
