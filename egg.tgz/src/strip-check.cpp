// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("strip check\n", stdout);
  return lionss_run_workload("strip-check");
}
