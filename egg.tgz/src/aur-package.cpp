// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("aur package\n", stdout);
  return lionss_run_workload("aur-package");
}
